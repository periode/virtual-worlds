﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FadeOutAndLoadScene : MonoBehaviour
{
    public Image fadeImage;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider col){
        StartCoroutine(LoadYourAsyncScene());
    }

    IEnumerator LoadYourAsyncScene(){

        AsyncOperation loadingScene = SceneManager.LoadSceneAsync("MusicScene"); //-- start loading the scene
        loadingScene.allowSceneActivation = false; //-- but don't activate it quite yet!

        float fade = 0f;

        while (!loadingScene.isDone){

            //-- we fade in the Screen Space UI Image
            fade += 0.1f;
            fadeImage.color = new Color(1, 1, 1, fade);

            yield return new WaitForSeconds(0.1f);

            //-- once it's toally faded in, we let the scene activate!
            if(fade > 1.0f){
                loadingScene.allowSceneActivation = true;
            }
        }

        yield return new WaitForSeconds(1f);
    }
}
