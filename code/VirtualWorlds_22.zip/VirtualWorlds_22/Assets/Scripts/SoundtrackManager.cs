﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundtrackManager : MonoBehaviour
{
    void Awake() { //-- Awake is called even before Start()!
        if(GameObject.FindGameObjectsWithTag("Music").Length > 1){ //-- is there already an object in the scene called background music?
            Destroy(this.gameObject); //-- if yes, then we get rid of ourselves, to not have duplicates
        }else{
            DontDestroyOnLoad(this.gameObject); //-- otherwise, we tell Unity not to get rid of us when we change the scene
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
