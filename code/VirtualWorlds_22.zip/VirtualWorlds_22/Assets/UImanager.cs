﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UImanager : MonoBehaviour
{
    public GameObject welcomeText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
     if(Input.GetKeyDown(KeyCode.Escape)){
         //-- deactivate any possible UI elements that is currently active

         //-- find all UI elements
         GameObject[] allUIElements = GameObject.FindGameObjectsWithTag("UI");

         // loop over all elements, and deactivate them
         foreach (GameObject UIElement in allUIElements)
         {
             UIElement.SetActive(false);
         }
     }   
    }

    public void OnTriggerEnter(Collider col){
        welcomeText.SetActive(true);
    }
}
