﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    CharacterController character;
    public float speed = 4f;
    public float rotateSpeed = 0.01f;
    public GameObject fpcamera; //first person camera
    public GameObject tpcamera; //third person

    // Start is called before the first frame update
    void Start()
    {
        character = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {

        //-- rotate
        float rotation = (Input.mousePosition.x - Screen.width / 2) / Screen.width; //-- normalize mouse position from the center, so that we get a a value between 0 and 1

        // if the rotation is too small (aka the mouse is in the center of the screen, we don't rotate at all)
        if (rotation > 0.2f || rotation < -0.2f)
        {
            transform.Rotate(0, rotation * rotateSpeed, 0);
        }

        //-- this part needs to be done in two steps, because we rotate the camera
        Vector3 forward = transform.TransformDirection(Vector3.forward) * Input.GetAxis("Vertical"); //-- take the direction we are facing, and multiply it by our vertical input
        Vector3 sidestep = transform.TransformDirection(Vector3.right) * Input.GetAxis("Horizontal"); //-- take the direction that is to our right, and multiply it by our horizontal input
        Vector3 direction = forward + sidestep; //-- we add those two vectors to get our final direction
        character.Move(direction * Time.deltaTime * speed); //-- and we multiply it by the deltaTime to account for framerate issues, and by our speed variable

        if (Input.GetKeyDown(KeyCode.Space))
        { //pressing space?
            if (fpcamera.activeSelf)
            { //which camera is active?
                fpcamera.SetActive(false); // -- this deactivates the first person camera
                tpcamera.SetActive(true);
            }
            else
            {
                fpcamera.SetActive(true);
                tpcamera.SetActive(false);
            }
        }
    }
}
