﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoadSceneManager : MonoBehaviour
{
    public Image fadeImage; //-- we grab the image on the canvas that we're going to fade in during the scene load duration.
    float alpha = 0.0f; //-- the starting alpha value of our fadeImage (0 = transparent)

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void LoadTargetScene(){ //-- this is the public function that gets connected to our UI Button

        //-- because we're doing things in the background, we need to run it as a coroutine
        StartCoroutine("LoadAsync");
    }

    IEnumerator LoadAsync()
    {

        //-- first we load the scene, and it returns an AsyncOperation variable,
        //-- which we will use to check on the progress
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync("TargetScene");

        //-- second, we tell the scene not to activate immediately once it's loaded
        //-- this prevents it from activating *before* our fading effect is done
        asyncLoad.allowSceneActivation = false;

        // Wait until the asynchronous scene fully loads AND until the fade effect is complete
        while (!asyncLoad.isDone && fadeImage.color.a <= 1.0f)
        {
            alpha += 0.1f;
            fadeImage.color = new Color(0, 0, 0, alpha);
            Debug.Log("Setting alpha to: " + alpha);
            yield return new WaitForSeconds(0.05f);
        }

        Debug.Log("We're done setting the alpha and the scene is loaded in the background! Activating next scene...");

        asyncLoad.allowSceneActivation = true;
    }
}
