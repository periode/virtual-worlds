﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LectureManager : MonoBehaviour
{
    // Start is called before the first frame update
    public AudioSource lectureAudio;
    public ParticleSystem knowledgeRepresentation;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(){
        lectureAudio.Play();
        knowledgeRepresentation.Play();
    }

    void OnTriggerExit(){
        lectureAudio.Stop();
        knowledgeRepresentation.Stop();
    }
}
