﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TableManager : MonoBehaviour
{
    // Start is called before the first frame update

    GameObject[] tables;
    void Start()
    {
        tables = GameObject.FindGameObjectsWithTag("Table");
        for(int i = 0; i < tables.Length; i++){
            tables[i].SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator RevealTables(){
        for(int i = 0; i < tables.Length; i++){
            tables[i].SetActive(true);
            yield return new WaitForSeconds(0.25f);
        }
    }

    void ShowTables(){
        StartCoroutine("RevealTables");
    }

    void OnTriggerEnter(){
        ShowTables();
    }
}
