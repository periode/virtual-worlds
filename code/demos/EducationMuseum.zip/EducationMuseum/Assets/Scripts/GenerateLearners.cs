﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateLearners : MonoBehaviour
{
    // Start is called before the first frame update
    public int circleRadius = 3;
    public int numberOfLearners = 8;
    public GameObject learner;
    Vector3[] positions;
    void Start()
    {
        positions = new Vector3[numberOfLearners];
        float inc = (Mathf.PI*2f)/numberOfLearners;

        int j = 0;
        for(float i = 0; i < Mathf.PI*2f-0.5f; i += inc){
            positions[j] = new Vector3(Mathf.Cos(i)*circleRadius, 0, Mathf.Sin(i)*circleRadius);
            GameObject go = Instantiate(learner, new Vector3(0, 0, 0), Quaternion.identity);
            go.transform.SetParent(this.transform);
            go.transform.localPosition = positions[j];
            j++;
        }
    }

    // Update is called once per frame
    void Update()
    {
        transform.RotateAround(transform.position, Vector3.up, 5 * Time.deltaTime);
    }
}
