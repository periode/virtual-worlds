﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public CharacterController characterController;
    public float speed = 6;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    void Move(){
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        Vector3 move = transform.forward * v + transform.right * h;
        characterController.Move(speed * Time.deltaTime * move);

        if(Input.GetMouseButton(0)){
            float r = Input.GetAxis("Mouse X");
            transform.Rotate(0, r * 4f, 0);   
        }
    }
}
