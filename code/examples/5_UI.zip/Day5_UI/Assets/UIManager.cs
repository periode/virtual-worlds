﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //-- IMPORTANT -- this is what allows us to interact with UI components, such as Text, etc.

public class UIManager : MonoBehaviour
{
    public GameObject cube;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ToggleCube(){
        if(cube.GetComponent<MeshRenderer>().enabled == true){
            cube.GetComponent<MeshRenderer>().enabled = false;
        }else{
            cube.GetComponent<MeshRenderer>().enabled = true;
        }
    }

    public void ChangeText(){
        //-- if we do not specify "using UnityEngine.UI" on line 4, the line below will give us an error :(
        //-- because we're trying to access a UI component without including the UI namespace
        GameObject.Find("HeaderText").GetComponent<Text>().text = "hello there!";
    }
}
