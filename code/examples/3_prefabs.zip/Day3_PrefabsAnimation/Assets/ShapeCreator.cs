﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShapeCreator : MonoBehaviour
{
    public GameObject shape;
    GameObject shapeContainer;
    // Start is called before the first frame update
    void Start()
    {
        shapeContainer = GameObject.Find("ShapeContainer");
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space)){
            GameObject go = Instantiate(shape, new Vector3(Random.Range(-2, 2), Random.Range(-2, 2), Random.Range(-2, 2)), Quaternion.identity);
            go.transform.SetParent(shapeContainer.transform);
        }
    }
}
