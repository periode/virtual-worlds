﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaycastManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        // this allows us to actually see the ray of our raycast
        Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * 10, Color.red);

        // here we declare a variable to store the results of our ray hitting something
        RaycastHit hit;

        // here we actually shoot the ray, starting from our current position, going forward unto infinity
        if(Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, Mathf.Infinity)){

            // we access the gameobject that we've hit
            GameObject objectHit = hit.transform.gameObject;

            // and we scale it up
            objectHit.transform.localScale = new Vector3(2, 2, 2);
        }
    }
}
