﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneManager : MonoBehaviour
{
    // first we declare the overall delegate, which will then allow us to have events attached to it
    public delegate void Subscription();

    // and here is the actual event
    public static event Subscription OnCollision;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter(){

        // here we are calling the event. any other script that has something registered to that event will react to this
        // for instance, see CapsuleManager.cs, line 11
        OnCollision();
    }
}
