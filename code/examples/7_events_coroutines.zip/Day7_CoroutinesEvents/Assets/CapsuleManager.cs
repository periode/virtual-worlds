﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CapsuleManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        // here we register what to do when the OnCollision event in our PlaneManager happens (see PlaneManager.cs, line 29)
        PlaneManager.OnCollision += HandleCollision;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void HandleCollision(){
        // Call the ChangeColor() function after a random amount of seconds
        // Invoke("ChangeColor", Random.Range(0.5f, 1.0f));

        // start our coroutine
        StartCoroutine("ChangeColorOverTime");
    }

    IEnumerator ChangeColorOverTime(){

        // we go from 1 to 0, with steps of 0.1
        for(float i = 1; i > 0; i -= 0.1f){

            // we set the color of the material of our object, from 1 to 0
            GetComponent<MeshRenderer>().material.color = new Color(i, i, i);

            // then we tell the coroutine to wait for 0.01 seconds, creating a fade effect
            yield return new WaitForSeconds(0.01f);
        }
    }

    void ChangeColor(){
        GetComponent<MeshRenderer>().material.color = Color.black;
    }
}
