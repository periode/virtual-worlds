﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeMovement : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 lastPosition = GetComponent<Transform>().position;
        //-- move up and down
        if(Input.GetKey(KeyCode.W)){
            Debug.Log("we pressed the key W");

            GetComponent<Transform>().position = new Vector3(lastPosition.x, lastPosition.y + 0.1f, lastPosition.z);
        }

        if(Input.GetKey(KeyCode.S)){
            GetComponent<Transform>().position = new Vector3(lastPosition.x, lastPosition.y - 0.1f, lastPosition.z);
        }

        // -- move sideways
        if(Input.GetKey(KeyCode.A)){
            Debug.Log("we pressed the key A");

            GetComponent<Transform>().position = new Vector3(lastPosition.x + 0.1f, lastPosition.y, lastPosition.z);
        }

        if(Input.GetKey(KeyCode.D)){
            GetComponent<Transform>().position = new Vector3(lastPosition.x - 0.1f, lastPosition.y, lastPosition.z);
        }

        //-- move closer and further
        if(Input.GetKey(KeyCode.Q)){
            Debug.Log("we pressed the key Q");

            GetComponent<Transform>().position = new Vector3( lastPosition.x, lastPosition.y, lastPosition.z + 0.1f);
        }

        if(Input.GetKey(KeyCode.E)){
            GetComponent<Transform>().position = new Vector3( lastPosition.x, lastPosition.y, lastPosition.z - 0.1f);
        }
    }
}
